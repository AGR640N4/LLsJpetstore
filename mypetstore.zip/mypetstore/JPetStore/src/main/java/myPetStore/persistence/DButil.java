package myPetStore.persistence;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DButil {
    private static String driver="com.mysql.jdbc.Driver";
    private static String url="jdbc:mysql://127.0.0.1:3306/mypetstore";
    private static String username="root";
    private static String password="12345678";

    public static Connection getConnection()throws Exception{
        try{
            Class.forName(driver);
            return DriverManager.getConnection(url,username,password);
        }
        catch (Exception e){
           throw e;
        }
    }

    public static void closeConnection(Connection connection) throws Exception{
        if(connection!=null)
            connection.close();
    }

    public static void closePreparedStatement(PreparedStatement preparedStatement) throws Exception{
        if(preparedStatement!=null)
            preparedStatement.close();
    }

    public static void closeResultSet(ResultSet resultSet) throws Exception{
        if(resultSet!=null)
            resultSet.close();
    }

//    public static void main(String[]args){
//        String getItemListByProduct="select I.ITEMID,LISTPRICE,UNITCOST,SUPPLIER AS supplierId,I.PRODUCTID AS \"product.productId\",NAME AS \"product.name\",DESCN AS \"product.description\",CATEGORY AS \"product.categoryId\",STATUS,ATTR1 AS attribute1,ATTR2 AS attribute2, ATTR3 AS attribute3,ATTR4 AS attribute4,ATTR5 AS attribute5,QTY AS quantity from ITEM I, INVENTORY V, PRODUCT P where P.PRODUCTID = I.PRODUCTID and I.ITEMID = V.ITEMID and I.ITEMID = ?";
//        List<Item> list=new ArrayList<>();
//        String productId="EST-10";
//        try{
//            Connection connection= DButil.getConnection();
//            PreparedStatement ps=connection.prepareStatement(getItemListByProduct);
//            ps.setString(1,productId);
//            ResultSet rs=ps.executeQuery();
//            while(rs.next()){
//                Item item=new Item();
//                Product product=new Product();
//                item.setItemId(rs.getString(1));
//                item.setListPrice(BigDecimal.valueOf(Double.parseDouble(rs.getString(2))));
//                item.setUnitCost(BigDecimal.valueOf(Double.parseDouble(rs.getString(3))));
//                item.setSupplierId(Integer.parseInt(rs.getString(4)));
//                product.setProductId(rs.getString(5));
//                product.setName(rs.getString(6));
//                product.setDescription(rs.getString(7));
//                product.setCategoryId(rs.getString(8));
//                item.setProduct(product);
//                item.setStatus(rs.getString(9));
//                item.setAttribute1(rs.getString(10));
//                item.setAttribute2(rs.getString(11));
//                item.setAttribute3(rs.getString(12));
//                item.setAttribute4(rs.getString(13));
//                item.setAttribute5(rs.getString(14));
//                list.add(item);
//
//
//            }
//            rs.close();
//            ps.close();
//            connection.close();
//
//        }catch (Exception e){
//            e.printStackTrace();
//        }
//        System.out.println(list.get(0).getItemId());
//        return;}
}