package myPetStore.persistence.impl;

import myPetStore.domain.Sequence;
import myPetStore.persistence.DButil;
import myPetStore.persistence.sequenceDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class sequenceDaoImpl implements sequenceDao {
    private static String getSequence="SELECT name, nextid FROM SEQUENCE WHERE NAME = ?";
    private static String updateSequence="UPDATE SEQUENCE SET NEXTID = ? WHERE NAME = ?";
    @Override
    public Sequence getSequence(Sequence sequence) {
        Sequence sequence1=new Sequence();
        try{
            Connection connection= DButil.getConnection();
            PreparedStatement ps=connection.prepareStatement(getSequence);
            ps.setString(1,sequence.getName());
            ResultSet rs=ps.executeQuery();
            if(rs.next())
            {
                sequence1.setName(rs.getString(1));
                sequence1.setNextId(rs.getInt(2));
            }
            ps.close();
            rs.close();
            connection.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return sequence1;
    }

    @Override
    public void updateSequence(Sequence sequence) {
        try{
            Connection connection=DButil.getConnection();
            PreparedStatement ps=connection.prepareStatement(updateSequence);
            ps.setInt(1,sequence.getNextId());
            ps.setString(2,sequence.getName());
            ps.executeUpdate();
            ps.close();
            connection.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }
}
