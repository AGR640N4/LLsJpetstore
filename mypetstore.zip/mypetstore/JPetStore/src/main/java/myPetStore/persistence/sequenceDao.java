package myPetStore.persistence;

import myPetStore.domain.Sequence;

public interface sequenceDao {
    Sequence getSequence(Sequence sequence);
    void updateSequence(Sequence sequence);
}
