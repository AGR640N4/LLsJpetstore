package myPetStore.web;

import myPetStore.domain.Order;
import myPetStore.domain.register;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@WebServlet(name = "viewOrderServlet")
public class viewOrderServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


        HttpSession session=request.getSession();
        List<register> registration=new ArrayList<>();
        if(session.getAttribute("registration")!=null)
            registration=(List)session.getAttribute("registration");

        Date date=new Date();
        register reg=new register();
        reg.setDate(date.toString());
        reg.setDescription("下达订单"+((Order)session.getAttribute("order")).getOrderId());

        registration.add(reg);
        session.setAttribute("registration",registration);
        request.getRequestDispatcher("/WEB-INF/jsp/order/ViewOrder.jsp").forward(request,response);
    }
}
