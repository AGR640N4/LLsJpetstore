package myPetStore.web;


import myPetStore.domain.Account;
import myPetStore.domain.Order;
import myPetStore.service.OrderService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "MyOrder")
public class MyOrder extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session=request.getSession();
        Account account=(Account) session.getAttribute("user");
        OrderService orderService=new OrderService();
        List<Order> list= orderService.getOrdersByUsername(account.getUsername());

        session.setAttribute("orderList",list);
        request.getRequestDispatcher("WEB-INF/jsp/order/ListOrders.jsp").forward(request,response);

    }
}
