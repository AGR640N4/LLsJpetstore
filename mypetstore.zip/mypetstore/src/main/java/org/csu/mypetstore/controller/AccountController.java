package org.csu.mypetstore.controller;

import org.csu.mypetstore.domain.Account;
import org.csu.mypetstore.service.AccounService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttribute;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/Account")
public class AccountController {
    @Autowired
    private AccounService accounService;

    @RequestMapping("/SignInPage")
    public String viewSignInPage(HttpServletRequest servletRequest){
        HttpSession session=servletRequest.getSession();

        List<String> languages=new ArrayList<>();
        languages.add("Japanese");
        languages.add("English");
        languages.add("Chinese");

        session.setAttribute("languages",languages);

        List<String> categories=new ArrayList<>();
        categories.add("Dogs");
        categories.add("Fish");
        categories.add("Bird");

        session.setAttribute("categories",categories);

        return "/Account/SignIn";
    }
    @RequestMapping("/SignIn")
    public String signIn(Account account){
        if(account.getUsername()!=null){
            System.out.println(account.getLanguagePreference()+account.getFirstName());
            accounService.insertProfile(account);
            accounService.insertAccount(account);
            return "/Account/Login";
        }
        else
            return "/Account/SignIn";
    }
    @RequestMapping("/usernameIsExist")
    public void usernameIsExist(String username, HttpServletRequest request, HttpServletResponse response) throws IOException {
        Account account=accounService.getAccountByUsername(username);
        response.setContentType("text/plain");
        PrintWriter out=response.getWriter();

        if(account!=null)
            out.println("Exist");
        else
            out.println("NotExist");
        out.flush();
        out.close();

    }

    @RequestMapping("/SignOut")
    public String signOut(@SessionAttribute("account") Account account){
        account=null;
        return "/catalog/Main";
    }

    @GetMapping("/editAccount")
    public String viewEditAccount(){
        return "/Account/EditAccount";
    }
    @GetMapping("/updateAccount")
    public String updateAccount(@SessionAttribute("account") Account oldAccount,Account account){
        accounService.updateAccount(account);
        accounService.updateProfile(account);
        oldAccount=null;
        return "/Account/Login";
    }
}
