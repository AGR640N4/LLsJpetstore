package org.csu.mypetstore.controller;

import org.csu.mypetstore.domain.*;
import org.csu.mypetstore.service.AccounService;
import org.csu.mypetstore.service.CatalogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttribute;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@Controller
@RequestMapping("/catalog")
public class Catalogcontroller {

    @Autowired
    private CatalogService catalogService;
    @Autowired
    private AccounService accounService;

    @GetMapping("/viewMain")
    public String view(){
        return "/catalog/Main";
    }

    @GetMapping("/viewCategory")
    public String viewCategory(String categoryId, Model model){
        if(categoryId!=null)
        {
            Category category= catalogService.getCategory(categoryId);
            List<Product> productList= catalogService.getProductListByCategory(categoryId);
            model.addAttribute("category",category);
            model.addAttribute("productList",productList);
            return "/catalog/Category";
        }
        else
            return "/catalog/Main";
    }

    @GetMapping("/viewProduct")
    public String viewProduct(String productId,Model model){
        if(productId!=null){
            List<Item> itemList=catalogService.getItemListByProduct(productId);
            Product product=catalogService.getProduct(productId);
            model.addAttribute("itemList",itemList);
            model.addAttribute("product",product);
            return "/catalog/Product";
        }
        else return "/catalog/Category";
    }
    @GetMapping("/viewItemInformation")
    public String viewItemInformation(String itemId,Model model){
        if (itemId!=null){
            Item item=catalogService.getItem(itemId);
            Product product=catalogService.getProduct(item.getProduct().getProductId());
            model.addAttribute("item",item);
            model.addAttribute("product",product);
            return "/catalog/Item";
        }
        else return "/catalog/Product";
    }

    @GetMapping("/ViewSignIn")
    public String SignIn()  {

        return "/Account/Login";
    }
    @GetMapping("/getValidationCode")
    public void getValidationCode(HttpServletRequest request, HttpServletResponse response,Model model)throws IOException{
        HttpSession session=request.getSession();
        ValidationCode drawYzm=new ValidationCode();
        drawYzm.getCode(request,response);
        model.addAttribute("validationCode",drawYzm);
    }

    @GetMapping("CheckSignIn")
    public String CheckSignIn(String username, String password, String validationCode, @SessionAttribute("codeValidate")String codeValidate,HttpServletRequest request){
        Account account=accounService.getAccountByUsername(username);
        if(account.getPassword().equals(password)&&validationCode.equals(codeValidate))
        {
            HttpSession session=request.getSession();
            session.setAttribute("account",account);
            return "/catalog/Main";
        }
        return "/Account/Login";
    }

    @GetMapping("/viewCart")
    public String viewCart(String itemId,HttpServletRequest servletRequest){
        Item item;
        Cart cart=null;
        HttpSession session=servletRequest.getSession();
        cart=(Cart)session.getAttribute("cart");
        if(cart==null)
            cart=new Cart();
        item=catalogService.getItem(itemId);
        if(cart.containsItemId(itemId))
            cart.incrementQuantityByItemId(itemId);
        else
            cart.addItem(item,catalogService.getInventoryQuantity(itemId)>0);

        session.setAttribute("cart",cart);
        return "/Cart/Cart";
    }

}
