package org.csu.mypetstore.service;

import org.csu.mypetstore.domain.Account;
import org.csu.mypetstore.persistence.AccountMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AccounService {

    @Autowired
    AccountMapper accountMapper;

    public Account getAccountByUsername(String username)
    {
        return accountMapper.getAccountByUsername(username);
    }

    public void insertAccount(Account account){
        accountMapper.insertAccount(account);
    }

    public void insertProfile(Account account){accountMapper.insertProfile(account);}

    public void updateAccount(Account account){ accountMapper.updateAccount(account); }

    public void updateProfile(Account account){ accountMapper.updateProfile(account); }

}
