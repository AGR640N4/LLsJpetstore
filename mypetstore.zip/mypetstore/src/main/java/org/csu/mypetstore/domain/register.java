package org.csu.mypetstore.domain;

public class register {

    private String date;
    private String Category;
    private String ProductID;
    private String ItemID;
    private String Description;

    public register(){
        date="#";
        Category="#";
        ProductID="#";
        ItemID="#";
        Description="#";
    }

    public String getCategory() {
        return Category;
    }

    public void setCategory(String category) {
        Category = category;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getProductID() {
        return ProductID;
    }

    public void setProductID(String productID) {
        ProductID = productID;
    }

    public String getItemID() {
        return ItemID;
    }

    public void setItemID(String itemID) {
        ItemID = itemID;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }
}
