package org.csu.mypetstore.controller;

import org.csu.mypetstore.domain.*;
import org.csu.mypetstore.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttribute;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/Order")
public class OrderController {
    @Autowired
    OrderService orderService;

    @RequestMapping("/orderCustomerInfo")
    public String writeInfo(@SessionAttribute Account account, HttpServletRequest servletRequest){

        List<String> list=new ArrayList<>();
        list.add("Visa");
        list.add("MasterCard");
        list.add("American Express");

        HttpSession session=servletRequest.getSession();
        session.setAttribute("creditCardTypes",list);

        if(account!=null)
            return "/Order/orderCustomerInfo";
        else return "/Account/Login";
    }

    @RequestMapping("/insertOrder")
    public String insertOrders(@SessionAttribute Cart cart,@SessionAttribute Account account,Order order,HttpServletRequest request){



        Date date=new Date();
        order.setOrderDate(date);
        Long timeStamp = System.currentTimeMillis();
        order.setOrderId(timeStamp.hashCode());
        order.setUsername(account.getUsername());

        Sequence sequence=new Sequence();
        int num=cart.getCartItemList().size();
        List<CartItem> list=cart.getCartItemList();
        List<LineItem> listLineItem=new ArrayList<>();

        for(int i=0;i<num;i++){
            LineItem lineItem=new LineItem();
            CartItem cartItem=list.get(i);
            lineItem.setItem(cartItem.getItem());
            lineItem.setItemId(cartItem.getItem().getItemId());
            lineItem.setOrderId(order.getOrderId());
            lineItem.setQuantity(cartItem.getQuantity());
            lineItem.setUnitPrice(cartItem.getTotal());
            lineItem.setLineNumber(i);
            listLineItem.add(lineItem);
        }

        sequence.setName(String.valueOf(order.getOrderId()));
        sequence.setNextId(listLineItem.size());
        order.setLineItems(listLineItem);

        HttpSession session=request.getSession();
        session.setAttribute("order",order);



        String[]list1=request.getParameterValues("shippingAddressRequired");
        System.out.println(list1!=null);
        if (list1!=null)
            return "/Order/shippingForm";
        else {
            orderService.insertOrder(order);
            return "/Order/confirmOrder";
        }
    }

    @RequestMapping("/shippingInfo")
    public String shipping(@SessionAttribute Order order,Order shippingOrder,HttpServletRequest request){

        order.setShipToFirstName(shippingOrder.getShipToFirstName());
        order.setShipToLastName(shippingOrder.getShipToLastName());
        order.setShipAddress1(shippingOrder.getShipAddress1());
        order.setShipAddress2(shippingOrder.getShipAddress2());
        order.setShipState(shippingOrder.getShipState());
        order.setShipCity(shippingOrder.getShipCity());
        order.setShipZip(shippingOrder.getShipZip());
        order.setShipCountry(shippingOrder.getShipCountry());

        HttpSession session=request.getSession();
        session.setAttribute("order",order);

        orderService.insertOrder(order);
        return "/Order/confirmOrder";
    }

    @RequestMapping("/viewDetailedOrder")
    public String viewDetailedOrder(){
        return "/Order/viewOrder";
    }
}
