package org.csu.myPetStore.service;

import org.csu.myPetStore.domain.Item;
import org.csu.myPetStore.domain.LineItem;
import org.csu.myPetStore.domain.Order;
import org.csu.myPetStore.domain.Sequence;
import org.csu.myPetStore.persistence.impl.ItemDaoImpl;
import org.csu.myPetStore.persistence.impl.LineItemDaoImpl;
import org.csu.myPetStore.persistence.impl.OrderDaoImpl;
import org.csu.myPetStore.persistence.impl.sequenceDaoImpl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OrderService {

  private ItemDaoImpl itemDaoImpl;
  private OrderDaoImpl orderDaoImpl;
  private LineItemDaoImpl lineItemDaoImpl;
  private sequenceDaoImpl sequenceDaoImpl;

  public OrderService(){
    itemDaoImpl=new ItemDaoImpl();
    orderDaoImpl=new OrderDaoImpl();
    lineItemDaoImpl=new LineItemDaoImpl();
    sequenceDaoImpl=new sequenceDaoImpl();
  }

  public void insertOrder(Order order) {
    order.setOrderId(getNextId("ordernum"));
    for (int i = 0; i < order.getLineItems().size(); i++) {
      LineItem lineItem = (LineItem) order.getLineItems().get(i);
      String itemId = lineItem.getItemId();
      Integer increment = new Integer(lineItem.getQuantity());
      Map<String, Object> param = new HashMap<String, Object>(2);
      param.put("itemId", itemId);
      param.put("increment", increment);
      itemDaoImpl.updateInventoryQuantity(param);
    }

    orderDaoImpl.insertOrder(order);
    orderDaoImpl.insertOrderStatus(order);
    for (int i = 0; i < order.getLineItems().size(); i++) {
      LineItem lineItem = (LineItem) order.getLineItems().get(i);
      lineItem.setOrderId(order.getOrderId());
      lineItemDaoImpl.insertLineItem(lineItem);
    }
  }

  public Order getOrder(int orderId) {
    Order order = orderDaoImpl.getOrder(orderId);
    order.setLineItems(lineItemDaoImpl.getLineItemsByOrderId(orderId));

    for (int i = 0; i < order.getLineItems().size(); i++) {
      LineItem lineItem = (LineItem) order.getLineItems().get(i);
      Item item = itemDaoImpl.getItem(lineItem.getItemId());
      item.setQuantity(itemDaoImpl.getInventoryQuantity(lineItem.getItemId()));
      lineItem.setItem(item);
    }

    return order;
  }

  public List<Order> getOrdersByUsername(String username) {
    return orderDaoImpl.getOrdersByUsername(username);
  }

  public int getNextId(String name) {
    Sequence sequence = new Sequence(name, -1);
    sequence = sequenceDaoImpl.getSequence(sequence);
    if (sequence == null) {
      throw new RuntimeException("Error: A null sequence was returned from the database (could not get next " + name
          + " sequence).");
    }
    Sequence parameterObject = new Sequence(name, sequence.getNextId() );
    sequenceDaoImpl.updateSequence(parameterObject);
    return sequence.getNextId();
  }

}
