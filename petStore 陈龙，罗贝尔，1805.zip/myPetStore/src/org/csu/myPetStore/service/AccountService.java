package org.csu.myPetStore.service;

import org.csu.myPetStore.domain.Account;
import org.csu.myPetStore.persistence.impl.AccountDaoImpl;

public class AccountService {

  private AccountDaoImpl accountDaoImpl;
  public  AccountService(){
    accountDaoImpl=new AccountDaoImpl();
  }
  public Account getAccount(String username) {
    return accountDaoImpl.getAccountByUsername(username);
  }

  public Account getAccount(String username, String password) {
    Account account = new Account();
    account.setUsername(username);
    account.setPassword(password);
    return accountDaoImpl.getAccountByUsernameAndPassword(account);
  }

  public void insertAccount(Account account) {
    accountDaoImpl.insertAccount(account);
    accountDaoImpl.insertProfile(account);
    accountDaoImpl.insertSignon(account);
  }

  public void updateAccount(Account account) {
    accountDaoImpl.updateAccount(account);
    accountDaoImpl.updateProfile(account);

    if (account.getPassword() != null && account.getPassword().length() > 0) {
      accountDaoImpl.updateSignon(account);
    }
  }

}
