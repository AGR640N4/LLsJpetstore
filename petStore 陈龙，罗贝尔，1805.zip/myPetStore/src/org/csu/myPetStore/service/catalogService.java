package org.csu.myPetStore.service;
import org.csu.myPetStore.domain.*;
import org.csu.myPetStore.persistence.impl.*;
import java.util.List;

public class catalogService {
    private CategoryDaoImpl categoryDaoImpl;
    private ProductDaoImpl productDaoImpl;
    private ItemDaoImpl itemDaoImpl;

    public catalogService(){
        categoryDaoImpl=new CategoryDaoImpl();
        productDaoImpl=new ProductDaoImpl();
        itemDaoImpl=new ItemDaoImpl();
    }

    public List<Category> getCategoryList() {
        return categoryDaoImpl.getCategoryList();
    }

    public Category getCategory(String categoryId) {
        return categoryDaoImpl.getCategory(categoryId);
    }

    public Product getProduct(String productId) {
        return productDaoImpl.getProduct(productId);
    }

    public List<Product> getProductListByCategory(String categoryId) {
        return productDaoImpl.getProductListByCategory(categoryId);
    }

    // TODO enable using more than one keyword
    public List<Product> searchProductList(String keyword) {
        return productDaoImpl.searchProductList("%" + keyword.toLowerCase() + "%");
    }

   public List<Item> getItemListByProduct(String productId) {
        return itemDaoImpl.getItemListByProduct(productId);
    }

    public Item getItem(String itemId) {
        return itemDaoImpl.getItem(itemId);
    }

    public boolean isItemInStock(String itemId) {
        return itemDaoImpl.getInventoryQuantity(itemId) > 0;
    }

}
