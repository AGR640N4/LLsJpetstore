package org.csu.myPetStore.persistence;
import org.csu.myPetStore.domain.Product;
import java.util.*;
public interface ProductDao {
    List<Product> getProductListByCategory(String categoryId);

    Product getProduct(String productId);

    List<Product> searchProductList(String keywords);
}
