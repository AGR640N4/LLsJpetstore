package org.csu.myPetStore.persistence;
import org.csu.myPetStore.domain.Category;
import java.util.*;

public interface CategoryDao {

    List<Category> getCategoryList();

    Category getCategory(String categoryId);
}
