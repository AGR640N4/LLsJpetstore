package org.csu.myPetStore.persistence;

import org.csu.myPetStore.domain.Sequence;

public interface sequenceDao {
    Sequence getSequence(Sequence sequence);
    void updateSequence(Sequence sequence);
}
