package org.csu.myPetStore.persistence.impl;

import org.csu.myPetStore.domain.Category;
import org.csu.myPetStore.persistence.CategoryDao;
import org.csu.myPetStore.persistence.DButil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class CategoryDaoImpl implements CategoryDao {
    private static final String getCategeoryList="SELECT CATID AS categoryId, NAME, DESCN AS description FROM CATEGORY";
    private static final String getCategory="SELECT CATID AS categoryId, NAME, DESCN AS description FROM CATEGORY WHERE CATID = ?";
    @Override
    public List<Category> getCategoryList(){
        List<Category> categoryList=new ArrayList<>();
        try{
            Connection connection=DButil.getConnection();
            PreparedStatement ps= connection.prepareStatement(getCategeoryList);
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                Category category=new Category();
                category.setCategoryId(rs.getString(1));
                category.setName(rs.getString(2));
                category.setDescription(rs.getString(3));
                categoryList.add(category);
            }
            connection.close();
            ps.close();
            rs.close();

        }
        catch (Exception e){
            e.printStackTrace();
        }
        return categoryList;
    }

    @Override
    public  Category getCategory(String categoryId) {
        Category category=new Category();
        try{
            Connection connection=DButil.getConnection();
            PreparedStatement ps= connection.prepareStatement(getCategory);
            ps.setString(1,categoryId);
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                category.setCategoryId(rs.getString(1));
                category.setName(rs.getString(2));
                category.setDescription(rs.getString(3));
            }
            connection.close();
            ps.close();
            rs.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return category;

    }

}
