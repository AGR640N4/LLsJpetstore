package org.csu.myPetStore.persistence.impl;

import org.csu.myPetStore.domain.Account;
import org.csu.myPetStore.persistence.AccountDao;
import org.csu.myPetStore.persistence.DButil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class AccountDaoImpl implements AccountDao {
    private static final String getAccountByUsername="SELECT SIGNON.USERNAME,SIGNON.PASSWORD, ACCOUNT.EMAIL, ACCOUNT.FIRSTNAME, ACCOUNT.LASTNAME, ACCOUNT.STATUS, ACCOUNT.ADDR1 AS address1, ACCOUNT.ADDR2 AS address2, ACCOUNT.CITY, ACCOUNT.STATE, ACCOUNT.ZIP, ACCOUNT.COUNTRY,ACCOUNT.PHONE, PROFILE.LANGPREF AS languagePreference, PROFILE.FAVCATEGORY AS favouriteCategoryId, PROFILE.MYLISTOPT AS listOption, PROFILE.BANNEROPT AS bannerOption, BANNERDATA.BANNERNAME FROM ACCOUNT, PROFILE, SIGNON, BANNERDATA WHERE ACCOUNT.USERID = ? AND SIGNON.USERNAME = ACCOUNT.USERID AND PROFILE.USERID = ACCOUNT.USERID AND PROFILE.FAVCATEGORY = BANNERDATA.FAVCATEGORY";
    private static final String getAccountByUsernameAndPassword="SELECT SIGNON.USERNAME,SIGNON.PASSWORD, ACCOUNT.EMAIL, ACCOUNT.FIRSTNAME, ACCOUNT.LASTNAME, ACCOUNT.STATUS, ACCOUNT.ADDR1 AS address1, ACCOUNT.ADDR2 AS address2, ACCOUNT.CITY, ACCOUNT.STATE, ACCOUNT.ZIP, ACCOUNT.COUNTRY,ACCOUNT.PHONE, PROFILE.LANGPREF AS languagePreference, PROFILE.FAVCATEGORY AS favouriteCategoryId, PROFILE.MYLISTOPT AS listOption, PROFILE.BANNEROPT AS bannerOption, BANNERDATA.BANNERNAME FROM ACCOUNT, PROFILE, SIGNON, BANNERDATA WHERE ACCOUNT.USERID = ? AND SIGNON.PASSWORD = ? AND SIGNON.USERNAME = ACCOUNT.USERID AND PROFILE.USERID = ACCOUNT.USERID AND PROFILE.FAVCATEGORY = BANNERDATA.FAVCATEGORY";
    private static final String insertAccount="INSERT INTO ACCOUNT(EMAIL, FIRSTNAME, LASTNAME, STATUS, ADDR1, ADDR2, CITY, STATE, ZIP, COUNTRY, PHONE, USERID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    private static final String insertProfile=" INSERT INTO PROFILE (LANGPREF, FAVCATEGORY, USERID)VALUES (?,?, ?)";
    private static final String insertSignon=" INSERT INTO SIGNON (PASSWORD,USERNAME, FAVCATEGORY) VALUES (?,?,?)";
    private static final String updateAccount=" UPDATE ACCOUNT SET EMAIL = ?, FIRSTNAME = ?,LASTNAME = ?, STATUS = ?,ADDR1 = ?, ADDR2 = ?, CITY = ?, STATE = ?,ZIP = ?, COUNTRY = ?,PHONE = ? WHERE USERID = ?";
    private static final String updateProfile="UPDATE PROFILE SET LANGPREF = ?, FAVCATEGORY = ? WHERE USERID = ?";
    private static final String updateSignon=" UPDATE SIGNON SET PASSWORD = ? WHERE USERNAME = ?";

    @Override
    public Account getAccountByUsername(String username) {
        Account account=new Account();
        try{
            Connection connection= DButil.getConnection();
            PreparedStatement ps= connection.prepareStatement(getAccountByUsername);
            ps.setString(1,username);
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                account.setUsername(rs.getString(1));
                account.setPassword(rs.getString(2));
                account.setEmail(rs.getString(3));
                account.setFirstName(rs.getString(4));
                account.setLastName(rs.getString(5));
                account.setStatus(rs.getString(6));
                account.setAddress1(rs.getString(7));
                account.setAddress2(rs.getString(8));
                account.setCity(rs.getString(9));
                account.setState(rs.getString(10));
                account.setZip(rs.getString(11));
                account.setCountry(rs.getString(12));
                account.setPhone(rs.getString(13));
                account.setLanguagePreference(rs.getString(14));
                account.setFavouriteCategoryId(rs.getString(15));
                account.setListOption(rs.getBoolean(16));
                account.setBannerOption(rs.getBoolean(17));
                account.setBannerName(rs.getString(18));
            }
            connection.close();
            ps.close();
            rs.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return account;
    }

    @Override
    public Account getAccountByUsernameAndPassword(Account account) {
        try{
            Connection connection= DButil.getConnection();
            PreparedStatement ps= connection.prepareStatement(getAccountByUsernameAndPassword);
            ps.setString(1,account.getUsername());
            ps.setString(2,account.getPassword());
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                account.setUsername(rs.getString(1));
                account.setPassword(rs.getString(2));
                account.setEmail(rs.getString(3));
                account.setFirstName(rs.getString(4));
                account.setLastName(rs.getString(5));
                account.setStatus(rs.getString(6));
                account.setAddress1(rs.getString(7));
                account.setAddress2(rs.getString(8));
                account.setCity(rs.getString(9));
                account.setState(rs.getString(10));
                account.setZip(rs.getString(11));
                account.setCountry(rs.getString(12));
                account.setPhone(rs.getString(13));
                account.setLanguagePreference(rs.getString(14));
                account.setFavouriteCategoryId(rs.getString(15));
                account.setListOption(rs.getBoolean(16));
                account.setBannerOption(rs.getBoolean(17));
                account.setBannerName(rs.getString(18));
            }
            connection.close();
            ps.close();
            rs.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return account;
    }

    @Override
    public void insertAccount(Account account) {
        try{
            Connection connection=DButil.getConnection();
            PreparedStatement ps= connection.prepareStatement(insertAccount);

            ps.setString(1,account.getEmail());
            ps.setString(2,account.getFirstName());
            ps.setString(3,account.getLastName());
            ps.setString(4,account.getStatus());
            ps.setString(5,account.getAddress1());
            ps.setString(6,account.getAddress2());
            ps.setString(7,account.getCity());
            ps.setString(8,account.getState());
            ps.setString(9,account.getZip());
            ps.setString(10,account.getCountry());
            ps.setString(11,account.getPhone());
            ps.setString(12,account.getUsername());
            ps.executeUpdate();

            connection.close();
            ps.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void insertProfile(Account account) {
        try{
            Connection connection=DButil.getConnection();
            PreparedStatement ps= connection.prepareStatement(insertProfile);

            ps.setString(1,account.getLanguagePreference());
            ps.setString(2,account.getFavouriteCategoryId());
            ps.setString(3,account.getUsername());

            ps.executeUpdate();

            connection.close();
            ps.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void insertSignon(Account account) {
        try{
            Connection connection=DButil.getConnection();
            PreparedStatement ps= connection.prepareStatement(insertSignon);

            ps.setString(1,account.getPassword());
            ps.setString(2,account.getUsername());
            ps.executeUpdate();

            connection.close();
            ps.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void updateAccount(Account account) {
        try{
            Connection connection=DButil.getConnection();
            PreparedStatement ps= connection.prepareStatement(updateAccount);
            ps.setString(1,account.getEmail());
            ps.setString(2,account.getFirstName());
            ps.setString(3,account.getLastName());
            ps.setString(4,account.getStatus());
            ps.setString(5,account.getAddress1());
            ps.setString(6,account.getAddress2());
            ps.setString(7,account.getCity());
            ps.setString(8,account.getState());
            ps.setString(9,account.getZip());
            ps.setString(10,account.getCountry());
            ps.setString(11,account.getPhone());
            ps.setString(12,account.getUsername());

            ps.executeUpdate();

            connection.close();
            ps.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void updateProfile(Account account) {
        try{
            Connection connection=DButil.getConnection();
            PreparedStatement ps= connection.prepareStatement(updateProfile);

            ps.setString(1,account.getLanguagePreference());
            ps.setString(2,account.getFavouriteCategoryId());
            ps.setString(3,account.getUsername());
            ps.executeUpdate();

            connection.close();
            ps.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void updateSignon(Account account) {
        try{
            Connection connection=DButil.getConnection();
            PreparedStatement ps= connection.prepareStatement(updateSignon);
            ps.setString(1,account.getPassword());
            ps.executeUpdate();

            connection.close();
            ps.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }
}
