package org.csu.myPetStore.persistence.impl;

import org.csu.myPetStore.domain.Product;
import org.csu.myPetStore.persistence.DButil;
import org.csu.myPetStore.persistence.ProductDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ProductDaoImpl implements ProductDao {
    private static final String getProductListByCategory="SELECT PRODUCTID,NAME,DESCN as description,CATEGORY as categoryId FROM PRODUCT WHERE CATEGORY=?";
    private static final String getParameterType="SELECT PRODUCTID,NAME,DESCN as description,CATEGORY as categoryId FROM PRODUCT WHERE PRODUCTID = ?";
    private static final String searchProductList="select PRODUCTID, NAME, DESCN as description, CATEGORY as categoryId from PRODUCT WHERE lower(name) like ?";
    @Override
    public List<Product> getProductListByCategory(String categoryId) {
        List<Product> list=new ArrayList<>();
        try{
            Connection connection=DButil.getConnection();
            PreparedStatement ps=connection.prepareStatement(getProductListByCategory);
            ps.setString(1,categoryId);
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                Product product=new Product();
                product.setProductId(rs.getString(1));
                product.setName(rs.getString(2));
                product.setDescription(rs.getString(3));
                product.setCategoryId(rs.getString(4));
                list.add(product);
            }
            rs.close();
            ps.close();
            connection.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public Product getProduct(String productId) {
        Product product=new Product();
        try{
            Connection connection=DButil.getConnection();
            PreparedStatement ps=connection.prepareStatement(getParameterType);
            ps.setString(1,productId);
            ResultSet rs=ps.executeQuery();
            if(rs.next()){
                product.setProductId(rs.getString(1));
                product.setName(rs.getString(2));
                product.setDescription(rs.getString(3));
                product.setCategoryId(rs.getString(4));
            }
            rs.close();
            ps.close();
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }

        return product;
    }

    @Override
    public List<Product> searchProductList(String keywords) {
        List<Product> list=new ArrayList<>();
        try{
            Connection connection=DButil.getConnection();
            PreparedStatement ps=connection.prepareStatement(searchProductList);
            ps.setString(1,'%'+ keywords+'%');
            ResultSet rs=ps.executeQuery();
            while (rs.next()){
                Product product=new Product();
                product.setProductId(rs.getString(1));
                product.setName(rs.getString(2));
                product.setDescription(rs.getString(3));
                product.setCategoryId(rs.getString(4));
                list.add(product);
            }
            rs.close();
            ps.close();
            connection.close();
        }
        catch (Exception e){
            e.printStackTrace();
         }
        return list;
    }
}
