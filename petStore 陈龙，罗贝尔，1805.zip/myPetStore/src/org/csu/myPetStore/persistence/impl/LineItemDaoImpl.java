package org.csu.myPetStore.persistence.impl;

import org.csu.myPetStore.domain.LineItem;
import org.csu.myPetStore.persistence.DButil;
import org.csu.myPetStore.persistence.LineItemDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class LineItemDaoImpl implements LineItemDao {
    private static final String getLineItemsByOrderId="SELECT ORDERID,LINENUM AS lineNumber,ITEMID,QUANTITY,UNITPRICE FROM LINEITEM WHERE ORDERID = ?";
    private static final String insertLineItem="INSERT INTO LINEITEM (ORDERID, LINENUM, ITEMID, QUANTITY, UNITPRICE) VALUES (?,?,?,?,?)";
    @Override
    public List<LineItem> getLineItemsByOrderId(int orderId) {
        List<LineItem> list=new ArrayList<>();
        try{
            Connection connection= DButil.getConnection();
            PreparedStatement ps=connection.prepareStatement(getLineItemsByOrderId);
            ps.setInt(1,orderId);
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                LineItem lineItem=new LineItem();
                lineItem.setOrderId(rs.getInt(1));
                lineItem.setLineNumber(rs.getInt(2));
                lineItem.setItemId(rs.getString(3));
                lineItem.setQuantity(rs.getInt(4));
                lineItem.setUnitPrice(rs.getBigDecimal(5));
                list.add(lineItem);
                ps.close();
                connection.close();
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public void insertLineItem(LineItem lineItem) {
        try{
            Connection connection=DButil.getConnection();
            PreparedStatement ps=connection.prepareStatement(insertLineItem);
            ps.setInt(1,lineItem.getOrderId());
            ps.setInt(2,lineItem.getLineNumber());
            ps.setString(3,lineItem.getItemId());
            ps.setInt(4,lineItem.getQuantity());
            ps.setBigDecimal(5,lineItem.getUnitPrice());
            ps.executeUpdate();
            ps.close();
            connection.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }
}
