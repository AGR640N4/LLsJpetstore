package org.csu.myPetStore.web;

import org.csu.myPetStore.domain.*;
import org.csu.myPetStore.service.catalogService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@WebServlet(name = "viewCart")
public class viewCart extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Item item;
        Cart cart=null;
        HttpSession session=request.getSession();
        catalogService cartService=new catalogService();
        cart=(Cart)session.getAttribute("cart");
        if(cart==null)
            cart=new Cart();
        String itemId=request.getParameter("itemId");
        if(cart.containsItemId(itemId)&&itemId!=null)
            cart.incrementQuantityByItemId(itemId);
        else if(itemId!=null)
        {
            item=cartService.getItem(itemId);
            cart.addItem(item,cartService.isItemInStock(itemId));
        }
        else {

        }
        session.setAttribute("cart",cart);


        List<register> registration=new ArrayList<>();
        if(session.getAttribute("registration")!=null)
            registration=(List)session.getAttribute("registration");

        Date date=new Date();
        register reg=new register();
        reg.setDate(date.toString());
        reg.setProductID(((Product)session.getAttribute("product")).getProductId());
        reg.setCategory(((Category)session.getAttribute("category")).getName());
        reg.setItemID(itemId);
        reg.setDescription("订单");

        registration.add(reg);
        session.setAttribute("registration",registration);


       request.getRequestDispatcher("/WEB-INF/jsp/cart/Cart.jsp").forward(request,response);
    }
}
