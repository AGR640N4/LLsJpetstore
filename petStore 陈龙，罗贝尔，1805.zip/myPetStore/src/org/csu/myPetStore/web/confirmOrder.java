package org.csu.myPetStore.web;

import org.csu.myPetStore.domain.*;
import org.csu.myPetStore.persistence.impl.sequenceDaoImpl;
import org.csu.myPetStore.service.OrderService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@WebServlet(name = "confirmOrder")
public class confirmOrder extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session=request.getSession();
        Order order=new Order();
        order.setCardType(request.getParameter("cardType"));
        order.setCreditCard(request.getParameter("order.creditCard"));
        order.setExpiryDate(request.getParameter("order.expiryDate"));
        order.setBillToFirstName(request.getParameter("order.billToFirstName"));
        order.setBillToLastName(request.getParameter("order.billToLastName"));
        order.setBillAddress1(request.getParameter("order.billAddress1"));
        order.setBillAddress2(request.getParameter("order.billAddress2"));
        order.setBillCity(request.getParameter("order.billCity"));
        order.setBillState(request.getParameter("order.billState"));
        order.setBillZip(request.getParameter("order.billZip"));
        order.setBillCountry(request.getParameter("order.billCountry"));
        Date date=new Date();

        order.setOrderDate(date);


        Sequence sequence=new Sequence();
        sequenceDaoImpl sequenceDao=new sequenceDaoImpl();
        List<CartItem> cartlist;
        List<LineItem> itemlist=new ArrayList<>();
        Cart cart=(Cart)session.getAttribute("cart");
        cartlist=cart.getCartItemList();
        for(int i=0;i<cartlist.size();i++)
        {
            LineItem lineItem=new LineItem();
            lineItem.setQuantity(cartlist.get(i).getQuantity());
            lineItem.setItem(cartlist.get(i).getItem());
            lineItem.setItemId(cartlist.get(i).getItem().getItemId());
            lineItem.setUnitPrice(cartlist.get(i).getTotal());
            sequence.setName("ordernum");
            lineItem.setOrderId(sequenceDao.getSequence(sequence).getNextId());
            order.setOrderId(sequence.getNextId());
            sequence.setNextId(sequence.getNextId()+1);
            sequenceDao.updateSequence(sequence);

            sequence.setName("linenum");
            lineItem.setLineNumber(sequenceDao.getSequence(sequence).getNextId());
            sequence.setNextId(sequence.getNextId()+1);
            sequenceDao.updateSequence(sequence);

            itemlist.add(lineItem);
        }
        order.setLineItems(itemlist);
        order.setTotalPrice(cart.getSubTotal());
        Account account=(Account)session.getAttribute("user");
        order.setUsername(account.getUsername());

        session.setAttribute("order",order);
        session.removeAttribute("cart");
        String[]list1=request.getParameterValues("shippingAddressRequired");

        if(list1!=null){
            request.getRequestDispatcher("/WEB-INF/jsp/order/ShippingForm.jsp").forward(request,response);
        }
        else {
            OrderService orderDao=new OrderService();
            orderDao.insertOrder(order);
            request.getRequestDispatcher("/WEB-INF/jsp/order/ConfirmOrder.jsp").forward(request,response);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);

    }
}
