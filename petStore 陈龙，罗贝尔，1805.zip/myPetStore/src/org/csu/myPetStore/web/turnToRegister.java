package org.csu.myPetStore.web;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "turnToRegister")
public class turnToRegister extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<String> languages=new ArrayList<>();
        languages.add("Japanese");
        languages.add("English");
        languages.add("Chinese");
        HttpSession session=request.getSession();
        List<String> categories=new ArrayList<>();
        categories.add("Dogs");
        categories.add("Fish");
        categories.add("Bird");
        session.setAttribute("categories",categories);
        session.setAttribute("languages",languages);
        request.getRequestDispatcher("/WEB-INF/jsp/account/NewAccountForm.jsp").forward(request,response);
    }
}
