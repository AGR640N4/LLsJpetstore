package org.csu.myPetStore.web;

import org.csu.myPetStore.domain.ValidationCode;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "createValidationServlet")
public class createValidationServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ValidationCode drawYzm=new ValidationCode();
        drawYzm.getCode(request,response);
        request.setAttribute("validationCode",drawYzm);
    }
}
