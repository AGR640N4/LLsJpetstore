package org.csu.myPetStore.web;

import org.csu.myPetStore.domain.Product;
import org.csu.myPetStore.service.catalogService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "search")
public class search extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String key=request.getParameter("keyword");
        catalogService searchService=new catalogService();
        List<Product> list;
        HttpSession session=request.getSession();

        list=searchService.searchProductList(key);
        session.setAttribute("productList",list);
        request.getRequestDispatcher("/WEB-INF/jsp/catalog/SearchProducts.jsp").forward(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
