package org.csu.myPetStore.web;

import org.csu.myPetStore.domain.Account;
import org.csu.myPetStore.service.AccountService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet(name = "LoginAccount")
public class LoginAccount extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session=request.getSession();

        String userName=request.getParameter("username");
        String password=request.getParameter("password");
        String yzm=request.getParameter("validationCode");
        String yzm1=(String) session.getAttribute("codeValidate");

        Account account;
        AccountService accountDao=new AccountService();
        account=accountDao.getAccount(userName);

        if(account.getPassword().equals(password)&&yzm.equals(yzm1))
        {
            session.setAttribute("user",account);
            String Main= "/WEB-INF/jsp/catalog/Main.jsp";
            request.getRequestDispatcher(Main).forward(request,response);
        }
        else{
            request.getRequestDispatcher("/WEB-INF/jsp/account/SignonForm.jsp").forward(request,response);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
