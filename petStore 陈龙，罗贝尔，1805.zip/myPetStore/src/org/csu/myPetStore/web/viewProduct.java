package org.csu.myPetStore.web;

import org.csu.myPetStore.domain.Category;
import org.csu.myPetStore.domain.Item;
import org.csu.myPetStore.domain.Product;
import org.csu.myPetStore.domain.register;
import org.csu.myPetStore.service.catalogService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@WebServlet(name = "viewProduct")
public class viewProduct extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Item> list;
        List<Product> mylist=new ArrayList<>();
        Product product;
        String productId=request.getParameter("productId");
        catalogService viewProduct=new catalogService();
        list=viewProduct.getItemListByProduct(productId);
        product=viewProduct.getProduct(productId);

        mylist.add(product);
        HttpSession session=request.getSession();

        List<register> registration=new ArrayList<>();
        if(session.getAttribute("registration")!=null)
            registration=(List)session.getAttribute("registration");


        Date date=new Date();
        register reg=new register();
        reg.setDate(date.toString());
        reg.setProductID(productId);
        reg.setCategory(((Category)session.getAttribute("category")).getName());
        reg.setDescription("浏览");

        registration.add(reg);
        session.setAttribute("registration",registration);

        session.setAttribute("itemList",list);
        session.setAttribute("product",product);
        session.setAttribute("myList",mylist);
        request.getRequestDispatcher("/WEB-INF/jsp/catalog/Product.jsp").forward(request,response);
    }
}
