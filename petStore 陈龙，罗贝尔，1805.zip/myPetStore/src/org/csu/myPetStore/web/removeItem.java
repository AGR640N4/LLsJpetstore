package org.csu.myPetStore.web;

import org.csu.myPetStore.domain.Cart;
import org.csu.myPetStore.service.catalogService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet(name = "removeItem")
public class removeItem extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cart cart;
        HttpSession session=request.getSession();
        catalogService cartService=new catalogService();
        cart=(Cart)session.getAttribute("cart");
        String itemId=request.getParameter("itemId");
        if(cart.containsItemId(itemId))
            cart.removeItemById(itemId);
        session.setAttribute("cart",cart);
        request.getRequestDispatcher("/WEB-INF/jsp/cart/Cart.jsp").forward(request,response);
    }
}
