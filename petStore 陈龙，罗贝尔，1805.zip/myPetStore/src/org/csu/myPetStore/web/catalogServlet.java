package org.csu.myPetStore.web;

import org.csu.myPetStore.domain.Category;
import org.csu.myPetStore.domain.Product;
import org.csu.myPetStore.domain.register;
import org.csu.myPetStore.service.catalogService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@WebServlet(name = "catalogServlet")
public class catalogServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String categoryId=request.getParameter("categoryId");
        catalogService viewService=new catalogService();
        List<Product> list;
        Category category;
        category=viewService.getCategory(categoryId);
        list=viewService.getProductListByCategory(categoryId);


        HttpSession session=request.getSession();
        session.setAttribute("category",category);
        session.setAttribute("productList",list);

        List<register> registration=new ArrayList<>();
        if(session.getAttribute("registration")!=null)
            registration=(List)session.getAttribute("registration");

        Date date=new Date();
        register reg=new register();
        reg.setDate(date.toString());
        reg.setCategory(categoryId);
        reg.setDescription("浏览");

        registration.add(reg);
        session.setAttribute("registration",registration);
        request.getRequestDispatcher("/WEB-INF/jsp/catalog/Category.jsp").forward(request,response);

    }
}