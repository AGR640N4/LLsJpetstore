package org.csu.myPetStore.web;

import org.csu.myPetStore.domain.Cart;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "ajaxChangeNumber")
public class ajaxChangeNumber extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
         doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cart cart;
        HttpSession session=request.getSession();
        cart=(Cart)session.getAttribute("cart");

        String itemId=request.getParameter("itemId");
        String itemNumber=request.getParameter("itemnumber");
        int number=Integer.parseInt(itemNumber);
        cart.setQuantityByItemId(itemId,number);
        response.setContentType("text/plain");
        PrintWriter out=response.getWriter();

        if(number==0)
            out.print("0");
        else{
            out.print("1");
        }
    }
}
