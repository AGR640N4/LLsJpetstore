package myPetStore.web;

import myPetStore.domain.Category;
import myPetStore.domain.Item;
import myPetStore.domain.Product;
import myPetStore.domain.register;
import myPetStore.service.catalogService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@WebServlet(name = "viewItem")
public class viewItem extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String itemId=request.getParameter("itemId");
        catalogService viewItemService=new catalogService();
        Item item;
        item=viewItemService.getItem(itemId);
        HttpSession session=request.getSession();
        session.setAttribute("item",item);

        List<register> registration=new ArrayList<>();
        if(session.getAttribute("registration")!=null)
            registration=(List)session.getAttribute("registration");


        Date date=new Date();
        register reg=new register();
        reg.setDate(date.toString());
        reg.setItemID(item.getItemId());
        reg.setProductID(((Product)session.getAttribute("product")).getProductId());
        reg.setCategory(((Category)session.getAttribute("category")).getName());
        reg.setDescription("浏览");

        registration.add(reg);
        session.setAttribute("registration",registration);

        request.getRequestDispatcher("/WEB-INF/jsp/catalog/Item.jsp").forward(request,response);
    }
}
