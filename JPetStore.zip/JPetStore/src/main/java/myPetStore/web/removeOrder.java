package myPetStore.web;


import myPetStore.domain.Cart;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "removeOrder")
public class removeOrder extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cart cart;
        HttpSession session=request.getSession();
        cart=(Cart)session.getAttribute("cart");
        String itemId=request.getParameter("itemId");
        cart.removeItemById(itemId);
        response.setContentType("text/plain");
        PrintWriter out=response.getWriter();
        session.setAttribute("cart",cart);
        if(cart.containsItemId(itemId))
            out.print("False");
        else
            out.print("OK,"+cart.getSubTotal());
    }
}
