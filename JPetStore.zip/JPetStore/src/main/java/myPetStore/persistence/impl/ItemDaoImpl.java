package myPetStore.persistence.impl;

import myPetStore.domain.Item;
import myPetStore.domain.Product;
import myPetStore.persistence.DButil;
import myPetStore.persistence.ItemDao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

public class ItemDaoImpl implements ItemDao {
    private static String getItem="select I.ITEMID,LISTPRICE,UNITCOST,SUPPLIER AS supplierId,I.PRODUCTID AS \"product.productId\",NAME AS \"product.name\",DESCN AS \"product.description\",CATEGORY AS \"product.categoryId\",STATUS,ATTR1 AS attribute1,ATTR2 AS attribute2,ATTR3 AS attribute3,ATTR4 AS attribute4,ATTR5 AS attribute5,QTY AS quantity from ITEM I, INVENTORY V, PRODUCT P where P.PRODUCTID = I.PRODUCTID and I.ITEMID = V.ITEMID and I.ITEMID = ?";
    private static String updateInventoryQuntity=" UPDATE INVENTORY SET QTY = QTY - ? WHERE ITEMID = ?";
    private static String getInventoryQuantity="SELECT QTY AS value FROM INVENTORY WHERE ITEMID = ?";
    @Override
    public void updateInventoryQuantity(Map<String, Object> param) {
        try{
            Set keys=param.keySet();
            Iterator iterator=keys.iterator();
            String itemId=iterator.next().toString();
            Integer QTY=(Integer)param.get(itemId);

            Connection connection= DButil.getConnection();
            PreparedStatement ps=connection.prepareStatement(updateInventoryQuntity);
            ps.setInt(1,QTY);
            ps.setString(2,itemId);
            ps.executeUpdate();
            ps.close();
            connection.close();


        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public int getInventoryQuantity(String itemId) {
        int Quntity=-1;
        try{
            Connection connection= DButil.getConnection();
            PreparedStatement ps=connection.prepareStatement(getInventoryQuantity);
            ps.setString(1,itemId);
            ResultSet rs=ps.executeQuery();
            if(rs.next())
                Quntity=rs.getInt(1);
            ps.close();
            rs.close();
            connection.close();

        }catch (Exception e){
            e.printStackTrace();
        }
        return Quntity;
    }

    @Override
    public List<Item> getItemListByProduct(String productId) {
        String getItemListByProduct="select I.ITEMID,LISTPRICE,UNITCOST,SUPPLIER AS supplierId,I.PRODUCTID AS \"product.productId\",NAME AS \"product.name\",DESCN AS \"product.description\",CATEGORY AS \"product.categoryId\",STATUS,ATTR1 AS attribute1,ATTR2 AS attribute2, ATTR3 AS attribute3,ATTR4 AS attribute4,ATTR5 AS attribute5,QTY AS quantity from ITEM I, INVENTORY V, PRODUCT P where P.PRODUCTID = I.PRODUCTID and I.ITEMID = V.ITEMID and I.PRODUCTID = ?";
        List<Item> list=new ArrayList<>();
        try{
            Connection connection= DButil.getConnection();
            PreparedStatement ps=connection.prepareStatement(getItemListByProduct);
            ps.setString(1,productId);
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                Item item=new Item();
                Product product=new Product();
                item.setItemId(rs.getString(1));
                item.setListPrice(BigDecimal.valueOf(Double.parseDouble(rs.getString(2))));
                item.setUnitCost(BigDecimal.valueOf(Double.parseDouble(rs.getString(3))));
                item.setSupplierId(Integer.parseInt(rs.getString(4)));
                product.setProductId(rs.getString(5));
                product.setName(rs.getString(6));
                product.setDescription(rs.getString(7));
                product.setCategoryId(rs.getString(8));
                item.setProduct(product);
                item.setStatus(rs.getString(9));
                item.setAttribute1(rs.getString(10));
                item.setAttribute2(rs.getString(11));
                item.setAttribute3(rs.getString(12));
                item.setAttribute4(rs.getString(13));
                item.setAttribute5(rs.getString(14));
                list.add(item);
            }
            rs.close();
            ps.close();
            connection.close();

        }catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public Item getItem(String itemId) {
        Item item=new Item();
        try{
            Connection connection=DButil.getConnection();
            PreparedStatement ps=connection.prepareStatement(getItem);
            ps.setString(1,itemId);
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                Product product=new Product();
                item.setItemId(rs.getString(1));
                item.setListPrice(BigDecimal.valueOf(Double.parseDouble(rs.getString(2))));
                item.setUnitCost(BigDecimal.valueOf(Double.parseDouble(rs.getString(3))));
                item.setSupplierId(Integer.parseInt(rs.getString(4)));
                product.setProductId(rs.getString(5));
                product.setName(rs.getString(6));
                product.setDescription(rs.getString(7));
                product.setCategoryId(rs.getString(8));
                item.setProduct(product);
                item.setStatus(rs.getString(9));
                item.setAttribute1(rs.getString(10));
                item.setAttribute2(rs.getString(11));
                item.setAttribute3(rs.getString(12));
                item.setAttribute4(rs.getString(13));
                item.setAttribute5(rs.getString(14));
            }
            ps.close();
            rs.close();
            connection.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return item;
    }
}
