package myPetStore.persistence.impl;

import myPetStore.domain.Order;
import myPetStore.persistence.DButil;
import myPetStore.persistence.OrderDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class OrderDaoImpl implements OrderDao {
    private static final String getOrdersByUsername="SELECT BILLADDR1 AS billAddress1, BILLADDR2 AS billAddress2, BILLCITY, BILLCOUNTRY,BILLSTATE,BILLTOFIRSTNAME,BILLTOLASTNAME,BILLZIP,SHIPADDR1 AS shipAddress1,SHIPADDR2 AS shipAddress2,SHIPCITY,SHIPCOUNTRY,SHIPSTATE,SHIPTOFIRSTNAME,SHIPTOLASTNAME,SHIPZIP,CARDTYPE,COURIER,CREDITCARD,EXPRDATE AS expiryDate,LOCALE,ORDERDATE,ORDERS.ORDERID,TOTALPRICE,USERID AS username,STATUS FROM ORDERS, ORDERSTATUS WHERE ORDERS.USERID = ? AND ORDERS.ORDERID = ORDERSTATUS.ORDERID ORDER BY ORDERDATE";
    private static final String getOrder="select BILLADDR1 AS billAddress1,BILLADDR2 AS billAddress2,BILLCITY,BILLCOUNTRY, BILLSTATE,BILLTOFIRSTNAME,BILLTOLASTNAME,BILLZIPSHIPADDR1 AS shipAddress1,SHIPADDR2 AS shipAddress2,SHIPCITY, SHIPCOUNTRY,SHIPSTATE,SHIPTOFIRSTNAME,SHIPTOLASTNAME,SHIPZIP,CARDTYPE,COURIER,CREDITCARD,EXPRDATE AS expiryDate,LOCALE,ORDERDATE,ORDERS.ORDERID,TOTALPRICE,USERID AS username,STATUS FROM ORDERS, ORDERSTATUS WHERE ORDERS.ORDERID = ? AND ORDERS.ORDERID = ORDERSTATUS.ORDERID";
    private static final String insertOrder="INSERT INTO ORDERS (ORDERID, USERID, ORDERDATE, SHIPADDR1, SHIPADDR2, SHIPCITY, SHIPSTATE,SHIPZIP, SHIPCOUNTRY, BILLADDR1, BILLADDR2, BILLCITY,BILLSTATE, BILLZIP, BILLCOUNTRY, TOTALPRICE, BILLTOFIRSTNAME, BILLTOLASTNAME, SHIPTOFIRSTNAME, SHIPTOLASTNAME,CREDITCARD, EXPRDATE, CARDTYPE)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    private static final String insertOrderStatus="INSERT INTO ORDERSTATUS (ORDERID, LINENUM, TIMESTAMP, STATUS) VALUES (?,?,?,?)";
    @Override
    public List<Order> getOrdersByUsername(String username) {
        List<Order> list=new ArrayList<>();
        try{
            Connection connection= DButil.getConnection();
            PreparedStatement ps=connection.prepareStatement(getOrdersByUsername);
            ps.setString(1,username);
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                Order order=new Order();
                order.setBillAddress1(rs.getString(1));
                order.setBillAddress2(rs.getString(2));
                order.setBillCity(rs.getString(3));
                order.setBillCountry(rs.getString(4));
                order.setBillState(rs.getString(5));
                order.setBillToFirstName(rs.getString(6));
                order.setBillToLastName(rs.getString(7));
                order.setBillZip(rs.getString(8));
                order.setShipAddress1(rs.getString(9));
                order.setShipAddress2(rs.getString(10));
                order.setShipCity(rs.getString(11));
                order.setShipCountry(rs.getString(12));
                order.setShipState(rs.getString(13));
                order.setShipToFirstName(rs.getString(14));
                order.setShipToLastName(rs.getString(15));
                order.setShipZip(rs.getString(16));

                order.setCardType(rs.getString(17));
                order.setCourier(rs.getString(18));
                order.setCreditCard(rs.getString(19));
                order.setExpiryDate(rs.getString(20));
                order.setLocale(rs.getString(21));
                order.setOrderDate(rs.getDate(22));
                order.setOrderId(rs.getInt(23));
                order.setTotalPrice(rs.getBigDecimal(24));
                order.setUsername(rs.getString(25));
                order.setStatus(rs.getString(26));
                list.add(order);
            }
            rs.close();
            ps.close();
            connection.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public Order getOrder(int orderId) {
       Order order=new Order();
       try{
           Connection connection= DButil.getConnection();
           PreparedStatement ps=connection.prepareStatement(getOrder);
           ps.setInt(1,orderId);
           ResultSet rs=ps.executeQuery();
           while(rs.next()){
               order.setBillAddress1(rs.getString(1));
               order.setBillAddress2(rs.getString(2));
               order.setBillCity(rs.getString(3));
               order.setBillCountry(rs.getString(4));
               order.setBillState(rs.getString(5));
               order.setBillToFirstName(rs.getString(6));
               order.setBillToLastName(rs.getString(7));
               order.setBillZip(rs.getString(8));
               order.setShipAddress1(rs.getString(9));
               order.setShipAddress2(rs.getString(10));
               order.setShipCity(rs.getString(11));
               order.setShipCountry(rs.getString(12));
               order.setShipState(rs.getString(13));
               order.setShipToFirstName(rs.getString(14));
               order.setShipToLastName(rs.getString(15));
               order.setShipZip(rs.getString(16));
               order.setCardType(rs.getString(17));
               order.setCourier(rs.getString(18));
               order.setCreditCard(rs.getString(19));
               order.setExpiryDate(rs.getString(20));
               order.setLocale(rs.getString(21));
               order.setOrderDate(rs.getDate(22));
               order.setOrderId(rs.getInt(23));
               order.setTotalPrice(rs.getBigDecimal(24));
               order.setUsername(rs.getString(25));
               order.setStatus(rs.getString(26));
       }
       }
       catch (Exception e){
           e.printStackTrace();
       }
       return order;
    }

    @Override
    public void insertOrder(Order order) {
        try{
            Connection connection=DButil.getConnection();
            PreparedStatement ps=connection.prepareStatement(insertOrder);
            ps.setInt(1,order.getOrderId());
            ps.setString(2,order.getUsername());
            ps.setDate(3,new java.sql.Date(order.getOrderDate().getTime()));
            ps.setString(4,order.getShipAddress1());
            ps.setString(5,order.getShipAddress2());
            ps.setString(6,order.getShipCity());
            ps.setString(7,order.getShipState());
            ps.setString(8,order.getShipZip());
            ps.setString(9,order.getShipCountry());
            ps.setString(10,order.getBillAddress1());
            ps.setString(11,order.getBillAddress2());
            ps.setString(12,order.getBillCity());
            ps.setString(13,order.getBillState());
            ps.setString(14,order.getBillZip());
            ps.setString(15,order.getBillCountry());

            ps.setBigDecimal(16,order.getTotalPrice());
            ps.setString(17,order.getBillToFirstName());
            ps.setString(18,order.getBillToLastName());
            ps.setString(19,order.getShipToFirstName());
            ps.setString(20,order.getShipToLastName());
            ps.setString(21,order.getCreditCard());
            ps.setString(22,order.getExpiryDate());
            ps.setString(23,order.getCardType());


            ps.executeUpdate();
            ps.close();
            connection.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void insertOrderStatus(Order order) {
        try{
            Connection connection=DButil.getConnection();
            PreparedStatement ps=connection.prepareStatement(insertOrderStatus);
            ps.setInt(1,order.getOrderId());
            ps.setInt(2,order.getLineItems().size());
            ps.setDate(3,new java.sql.Date(order.getOrderDate().getTime()));
            ps.setString(4,order.getStatus());

            ps.executeUpdate();
            ps.close();
            connection.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }
}
